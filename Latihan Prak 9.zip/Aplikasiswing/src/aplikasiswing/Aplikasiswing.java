/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aplikasiswing;

/**
 *
 * @author Evelyn
 */

import javax.swing.*;
import java.awt.event.*;


public abstract class Aplikasiswing implements ActionListener{

    /**
     * @param args the command line arguments
     */
    private static void createAndShowGUI() {
        // make frame
        JFrame frame = new JFrame("I am a JFrame"); frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(20,30,300,100);
        frame.getContentPane().setLayout(null);
        //make a button
        JButton button = new JButton("Click me");
        frame.getContentPane().add(button);
        button.setBounds(20,20,200,20);
        
        
        //instansiate an application object
       Aplikasiswing app = new Aplikasiswing() {};
        //make the label
        app.label = new JLabel("nama saya merupakan");
        app.label.setBounds(20,40,200,20);
        frame.getContentPane().add(app.label);
        //
        //
        button.addActionListener(app);
        frame.setVisible(true);
    }
    
    
public void actionPerformed(ActionEvent e)
{
    //
    //
    label.setText("Evelyn Winny");
}

    public static void main(String[] args) {
        //memulai swing GUI
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
    }
    
    JLabel label;
}
